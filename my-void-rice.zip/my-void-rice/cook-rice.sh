#!/bin/bash

set -e

if [ "$EUID" -ne 0 ]
  then echo "The script has to be run as root."
  exit
fi

BIN_DIR=${BIN_DIR:-/usr/local/bin/}
THEMES_DIR=${THEMES_DIR:-/usr/share/themes/}
APPS_DIR=${APPS_DIR:-/usr/local/share/applications/}
FONTS_DIR=${FONTS_DIR:-/usr/share/fonts/misc/}

checkinstdir() {
if [ -d $1 ]; then
	echo "$1 ok"
else
	echo "$1 is missing"
	exit -1
fi
}

echo "Checking directories"
checkinstdir $BIN_DIR
checkinstdir $THEMES_DIR
checkinstdir $APPS_DIR
checkinstdir $FONTS_DIR

pushd ./dwm
echo "Installing dwm"
make install

popd && pushd ./dmenu
echo "Installing dmenu"
make install

popd && pushd ./slstatus
echo "Installing slstatus"
make install

popd && pushd ./st
echo "Installing st"
make install
popd


echo "Installing Data"

echo "Installing themes"
cp -r data/themes/Shades* $THEMES_DIR

echo "Installing Siji font"
cp -r data/fonts/siji.bdf $FONTS_DIR
fc-cache -fv

echo "Installing Apps"
cp -r data/applications/*.desktop $APPS_DIR

echo "Adding Dots"
cp .bashrc /.config
cp .vimrc /.config
cp .xinitrc /.config
cp .Xresources /.config

echo "Install finished. Add software to .xinitrc to launch the DE with startx,
or copy the provided .xinitrc file to your home directory (backup the old one!)"

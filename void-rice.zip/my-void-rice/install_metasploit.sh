#!/bin/sh

if [ `id -u` != "0" ]; then
	echo "This should be run as root."
	exit
fi

missing=0
for dep in rsync curl; do
	if [ ! -x "$(which $dep 2>/dev/null)" ]; then
		echo "Missing $dep"
		missing=1
	fi
done

if [ $missing -eq 1 ]; then
	exit
fi

Repo="http://downloads.metasploit.com/data/releases/metasploit-framework/apt"
Packages="$Repo/dists/sid/main/binary-amd64/Packages"

echo -n "Finding latest version of Debian package..."
Filename=$(curl -sL $Packages | grep Filename | cut -f2 -d\ )
echo "OK."

echo -n "Setting up temporary working space..."
TmpDir=$(mktemp -d)
cd "$TmpDir"
echo "OK."

echo -n "Fetching Debian package..."
curl -sL -o msf.deb "$Repo/$Filename"
echo "OK."

echo -n "Extracting contents..."
ar x msf.deb
tar zxf data.tar.gz 
echo "OK."

echo -n "Moving files into place..."
rsync -azPr opt/metasploit-framework/ /opt/metasploit-framework >/dev/null 2>&1 
echo "OK."

echo -n "Replacing metasploit's update script..."
mv $(which $0) /opt/metasploit-framework/bin/msfupdate
echo "OK."

echo -n "Cleaning up temporary workspace..."
cd /
rm -rf "$TmpDir"
echo "OK."

echo -n "Making sure metasploit is in the path..."
cat <<'END' >/etc/bash/bashrc.d/metasploit.sh
PATH=$PATH:/opt/metasploit-framework/bin; export PATH
END
echo "OK."


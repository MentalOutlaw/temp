this is my very own rice with dwm st and slstatus.
start by running install_dependecies.sh as root
once that finishes run rice-void.sh as root

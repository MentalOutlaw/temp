# void-rice

## NEW in 0.5: Xresources support!

![photo](https://raw.githubusercontent.com/0x0f0f0f/void-rice/master/screenshots/01.png)
![photo](https://raw.githubusercontent.com/0x0f0f0f/void-rice/master/screenshots/02.png)

My lightweight Desktop Environment based on suckless tools.
Comes with Void Linux build and install scripts, and all the dwm features you need **out of the box**!
* Xresources support (loaded on dwm and st startup, reload hotkey is on the way for 0.6)
* Sane keybindings
* [tilegap](https://dwm.suckless.org/patches/tilegap/) to set gaps between windows
* [moveresize](https://dwm.suckless.org/patches/moveresize/) to resize/move windows
* [statuscolors](https://dwm.suckless.org/patches/statuscolors/) to set different colors for each situation (i.e. normal tags, selected tag, urgent tag, occupied tags)
* Adjustable transparency/alpha in the st terminal (needs compton)
* In the st terminal Copy is alt-c, paste is alt-v or alt-p pastes from primary selection
* Default font is system "mono" at 14pt, meaning the font will match your system/xresources font.
* Hold alt and press either ↑/↓ or the vim keys k/j to move up/down in the terminal.
* Shift+Mouse wheel will as well.
* Alt-u and Alt-d scroll back/forward in history a page at a time.
* Alt-PageUp and Alt-PageDown will do the same.
* Zoom in/out with Alt+Shift+k/j or u/d for larger intervals.
* Default spirited away colors.
* Detailed info in the statusbar with slstatus


## Forked Software included in this repo
* [dwm](https://dwm.suckless.org/)
* [st](https://st.suckless.org/)
* [slstatus](https://tools.suckless.org/slstatus/)
* [dmenu](https://tools.suckless.org/dmenu/)


## Downloading

`git clone --recursive https://github.com/0x0f0f0f/void-rice`

Remember to use `--recursive` or submodules won't be cloned.

## Installing

1) Fire up a text editor and edit `dependencies.txt` and config files as you'd like. 
2) For **Void Linux** Install dependencies by running `./install-dependencies.sh`. The script will simply read required packages from `dependencies.txt` and run xbps-install.
3) For **Other Distros** install the equivalent dependencies.
4) Build automatically by running `./build.sh` or manually by running `make` in each program's directory.
5) Install compiled software automatically by running `./install.sh` or with `sudo make install` in programs directories.
6) Set gtk and icon themes with `lxappearance`
7) Copy and tweak `.xinitrc` in your home folder.

## TLDR
```sh
cd void-rice # CD into this repository
sudo ./install-dependencies.sh # Install void packages
./build.sh  # Build
sudo ./install.sh # Install rice

mv ~/.xinitrc ~/.xinitrc.old # Backup old .xinitrc
cp .xinitrc ~/.xinitrc # Apply .xinitrc
```

Now set gtk a theme and icon pack. **slstatus** will likely fail to display correct values if not configuerd first.

If you edit the configuration files you'll need to rebuild and reinstall:
```sh
./build.sh && sudo ./install.sh
```

## Future Roadmap
* [ ] Xresources dmenu colors
* [ ] Xresources dunst colors? :)
* [ ] Xresources hot reload hotkey
* [ ] dwm hot reload hotkey/script that keeps windows alive and tidy
* [ ] Optional touchscreen/trackpad gesture support


## Thoughts for 1.0
Smartphone mode: There are interesting devices in development that will run mainline Linux. Since they are going viral even before getting released (and supposing they will be released with a bloated, user friendly interface) i'll look into adding **smartphone mode** to **void-rice** as soon as I get my hands on a small touchscreen with Xorg.
After the actual roadmap is complete i'll look into adding a bottom bar with buttons that trigger navigation and a monocle layout that splits in two vertically leaving space for a toggleable on-screen keyboard in the bottom slot.



  

## Recommended packages for Void Linux
* `icecat` GNU fork of firefox. Best browser out there.

#!/bin/bash

set -e

pushd ./dwm
echo "Compiling dwm"
make clean && make
popd && pushd ./dmenu
echo "Compiling dmenu"
make clean && make
popd && pushd ./slstatus
echo "Compiling slstatus"
make clean && make
popd && pushd ./st
echo "Compiling st"
make
popd

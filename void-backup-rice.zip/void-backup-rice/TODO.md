# TODO

* Unify color scheme and font definition between dwm, dmenu and st. Define once, replace everywhere. (awk??, sed??)
* Add dunst guide and better notification integration

